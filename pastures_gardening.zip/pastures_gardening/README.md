# PASTURES — Gardening & Maintenance Platform

Django REST backend + designed frontend screens for a gardening service platform: bookings, AI photo quotes, AR plant tracking, invoices, and Stripe payments.

## Push this to GitHub

```bash
cd pastures_gardening
git init
git add .
git commit -m "Initial commit: PASTURES backend + frontend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/pastures_gardening.git
git push -u origin main
```

(Create the empty repo on GitHub first, or run `gh repo create pastures_gardening --private --source=. --push` if you have the GitHub CLI installed.)

## Quick start (local)

```bash
python -m venv venv
source venv/bin/activate      # venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env          # then edit .env with real values

python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Visit `http://127.0.0.1:8000/static/index.html` for the landing page, or `http://127.0.0.1:8000/admin/` to add services and time slots.

## Deploying

- `.github/workflows/ci.yml` runs tests on every push/PR.
- `.github/workflows/deploy.yml` deploys to Fly.io on push to `main` — needs a `FLY_API_TOKEN` secret in your repo settings.
- `Dockerfile` is ready for `fly launch`.

See the Fly.io deploy guide from our earlier conversation for the full Sprite → Machines walkthrough.

## Structure

- `accounts/` — users, auth, password reset
- `bookings/` — services, time slots, bookings
- `quotes_invoices/` — AI photo estimator, quotes, invoices, PDF generation
- `garden_tracking/` — garden map, plants, AR markers
- `payments/` — Stripe Checkout + webhook
- `static/` — the six designed frontend screens (landing, dashboard, booking calendar, AR tracking, quote/invoice, reset password)
