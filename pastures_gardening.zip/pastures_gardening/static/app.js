const API_BASE = 'http://127.0.0.1:8000/api';

function getToken() { return localStorage.getItem('pastures_token'); }
function setToken(t) { localStorage.setItem('pastures_token', t); }
function authHeaders() { return { 'Authorization': `Token ${getToken()}` }; }

async function apiPOST(endpoint, data, isForm = false) {
    const opts = {
        method: 'POST',
        headers: isForm ? authHeaders() : { ...authHeaders(), 'Content-Type': 'application/json' },
        body: isForm ? data : JSON.stringify(data)
    };
    return await fetch(`${API_BASE}${endpoint}`, opts).then(r => r.json());
}

async function apiGET(endpoint) {
    return await fetch(`${API_BASE}${endpoint}`, { headers: authHeaders() }).then(r => r.json());
}

async function login(email, password) {
    const data = await apiPOST('/accounts/login/', { email, password });
    if (data.token) { setToken(data.token); localStorage.setItem('user', JSON.stringify(data.user)); }
    return data;
}

async function getServices() {
    return await fetch(`${API_BASE}/bookings/services/`).then(r => r.json());
}

async function getAvailableSlots(date) {
    return await fetch(`${API_BASE}/bookings/slots/?date=${date}`).then(r => r.json());
}

async function createBooking(service, slot, address, notes = '') {
    return await apiPOST('/bookings/', { service, slot, address, notes });
}
