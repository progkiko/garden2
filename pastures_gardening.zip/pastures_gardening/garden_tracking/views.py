from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import GardenMap, Plant
from .serializers import GardenMapSerializer, PlantSerializer, PlantLogUpdateSerializer


class GardenMapView(generics.RetrieveUpdateAPIView):
    """
    GET/PATCH /api/garden/map/ — the logged-in user's garden map and plant list,
    used to render the AR tracking screen's marker positions (layout_data).
    Creates an empty map on first access.
    """
    serializer_class = GardenMapSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        garden_map, _ = GardenMap.objects.get_or_create(user=self.request.user)
        return garden_map


class PlantListCreateView(generics.ListCreateAPIView):
    """GET/POST /api/garden/plants/ — list or add plants to the user's garden map."""
    serializer_class = PlantSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        garden_map, _ = GardenMap.objects.get_or_create(user=self.request.user)
        return garden_map.plants.all()

    def perform_create(self, serializer):
        garden_map, _ = GardenMap.objects.get_or_create(user=self.request.user)
        serializer.save(garden_map=garden_map)


class PlantDetailView(generics.RetrieveUpdateDestroyAPIView):
    """GET/PATCH/DELETE /api/garden/plants/<id>/"""
    serializer_class = PlantSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Plant.objects.filter(garden_map__user=self.request.user)


class PlantByMarkerView(APIView):
    """
    GET /api/garden/marker/<ar_marker_id>/ — resolves an AR marker scanned in-app
    to its plant record, for the 'tap a marker for detail' side panel.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, ar_marker_id):
        try:
            plant = Plant.objects.get(ar_marker_id=ar_marker_id, garden_map__user=request.user)
        except Plant.DoesNotExist:
            return Response({'detail': 'No plant found for that marker.'}, status=404)
        return Response(PlantSerializer(plant).data)


class PlantLogUpdateView(APIView):
    """
    POST /api/garden/plants/<id>/log/ — { health_status?, growth_percent?, note? }
    Updates a plant's health/growth after a visit. Wire `note` into a
    PlantActivityLog model if you want a persisted history like the
    'Recent activity' list on the AR screen.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            plant = Plant.objects.get(pk=pk, garden_map__user=request.user)
        except Plant.DoesNotExist:
            return Response({'detail': 'Plant not found.'}, status=404)

        serializer = PlantLogUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        if 'health_status' in data:
            plant.health_status = data['health_status']
        if 'growth_percent' in data:
            plant.growth_percent = data['growth_percent']
        plant.save()

        return Response(PlantSerializer(plant).data, status=status.HTTP_200_OK)
