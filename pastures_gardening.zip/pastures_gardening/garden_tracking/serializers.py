from rest_framework import serializers
from .models import GardenMap, Plant


class PlantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Plant
        fields = [
            'id', 'name', 'common_name', 'location', 'date_planted',
            'health_status', 'growth_percent', 'ar_marker_id',
        ]


class GardenMapSerializer(serializers.ModelSerializer):
    plants = PlantSerializer(many=True, read_only=True)

    class Meta:
        model = GardenMap
        fields = ['id', 'name', 'layout_data', 'plants']


class PlantLogUpdateSerializer(serializers.Serializer):
    """Body for logging a maintenance visit against a plant, e.g. from the AR view."""
    health_status = serializers.ChoiceField(choices=['healthy', 'watch', 'at_risk'], required=False)
    growth_percent = serializers.IntegerField(min_value=0, max_value=100, required=False)
    note = serializers.CharField(required=False, allow_blank=True)
