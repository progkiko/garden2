from django.urls import path
from . import views

app_name = 'garden_tracking'

urlpatterns = [
    path('map/', views.GardenMapView.as_view(), name='garden-map'),
    path('plants/', views.PlantListCreateView.as_view(), name='plant-list-create'),
    path('plants/<int:pk>/', views.PlantDetailView.as_view(), name='plant-detail'),
    path('plants/<int:pk>/log/', views.PlantLogUpdateView.as_view(), name='plant-log'),
    path('marker/<str:ar_marker_id>/', views.PlantByMarkerView.as_view(), name='plant-by-marker'),
]
