from django.db import models
from django.conf import settings


class GardenMap(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, default='My Garden')
    layout_data = models.JSONField(default=dict, blank=True)


class Plant(models.Model):
    garden_map = models.ForeignKey(GardenMap, related_name='plants', on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    common_name = models.CharField(max_length=100, blank=True)
    location = models.CharField(max_length=100, blank=True)
    date_planted = models.DateField(null=True)
    health_status = models.CharField(max_length=20, default='healthy')
    growth_percent = models.IntegerField(default=0)
    ar_marker_id = models.CharField(max_length=100, unique=True, null=True)
