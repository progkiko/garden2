import stripe
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from quotes_invoices.models import Invoice

stripe.api_key = settings.STRIPE_SECRET_KEY


class CreateCheckoutSessionView(APIView):
    """
    POST /api/payments/checkout/<invoice_id>/
    Creates a Stripe Checkout session for the 'Pay £X.XX' button on the invoice screen.
    Returns { checkout_url } for the frontend to redirect to.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, invoice_id):
        try:
            invoice = Invoice.objects.select_related('quote').get(pk=invoice_id, user=request.user)
        except Invoice.DoesNotExist:
            return Response({'detail': 'Invoice not found.'}, status=404)

        if invoice.paid:
            return Response({'detail': 'This invoice is already paid.'}, status=400)

        amount = invoice.quote.ai_estimate if invoice.quote else 0
        amount_pence = int(amount * 100)

        session = stripe.checkout.Session.create(
            mode='payment',
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'gbp',
                    'unit_amount': amount_pence,
                    'product_data': {'name': f'PASTURES invoice {invoice.invoice_ref}'},
                },
                'quantity': 1,
            }],
            metadata={'invoice_id': str(invoice.id)},
            success_url=f'{settings.FRONTEND_URL}/invoices/{invoice.id}?paid=1',
            cancel_url=f'{settings.FRONTEND_URL}/invoices/{invoice.id}?cancelled=1',
        )
        return Response({'checkout_url': session.url})


class StripeWebhookView(APIView):
    """
    POST /api/payments/webhook/
    Verifies the Stripe signature and marks the matching invoice as paid
    when a checkout.session.completed event arrives.
    """
    permission_classes = [permissions.AllowAny]

    @csrf_exempt
    def post(self, request):
        payload = request.body
        sig_header = request.META.get('HTTP_STRIPE_SIGNATURE', '')

        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
            )
        except (ValueError, stripe.error.SignatureVerificationError):
            return Response(status=status.HTTP_400_BAD_REQUEST)

        if event['type'] == 'checkout.session.completed':
            session = event['data']['object']
            invoice_id = session.get('metadata', {}).get('invoice_id')
            if invoice_id:
                Invoice.objects.filter(pk=invoice_id).update(paid=True)

        return Response(status=status.HTTP_200_OK)
