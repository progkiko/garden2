from django.urls import path
from . import views

app_name = 'payments'

urlpatterns = [
    path('checkout/<int:invoice_id>/', views.CreateCheckoutSessionView.as_view(), name='checkout'),
    path('webhook/', views.StripeWebhookView.as_view(), name='webhook'),
]
