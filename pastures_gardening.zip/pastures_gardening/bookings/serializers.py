from rest_framework import serializers
from .models import Service, TimeSlot, Booking


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = ['id', 'name', 'description', 'base_price', 'active']


class TimeSlotSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimeSlot
        fields = ['id', 'date', 'start_time', 'end_time', 'is_available']


class BookingSerializer(serializers.ModelSerializer):
    service_name = serializers.CharField(source='service.name', read_only=True)
    slot_date = serializers.DateField(source='slot.date', read_only=True)
    slot_start = serializers.TimeField(source='slot.start_time', read_only=True)
    slot_end = serializers.TimeField(source='slot.end_time', read_only=True)

    class Meta:
        model = Booking
        fields = [
            'id', 'service', 'service_name', 'slot', 'slot_date',
            'slot_start', 'slot_end', 'address', 'notes', 'status',
            'created_at',
        ]
        read_only_fields = ['status', 'created_at']

    def validate_slot(self, slot):
        if not slot.is_available:
            raise serializers.ValidationError('That time slot is no longer available.')
        return slot

    def create(self, validated_data):
        slot = validated_data['slot']
        booking = Booking.objects.create(
            user=self.context['request'].user,
            status='pending',
            **validated_data,
        )
        slot.is_available = False
        slot.save(update_fields=['is_available'])
        return booking
