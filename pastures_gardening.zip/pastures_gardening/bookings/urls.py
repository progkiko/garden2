from django.urls import path
from . import views

app_name = 'bookings'

urlpatterns = [
    path('services/', views.ServiceListView.as_view(), name='service-list'),
    path('slots/', views.AvailableSlotsView.as_view(), name='slot-list'),
    path('', views.BookingListCreateView.as_view(), name='booking-list-create'),
    path('<int:pk>/', views.BookingDetailView.as_view(), name='booking-detail'),
]
