from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils.dateparse import parse_date
from django.db import transaction

from .models import Service, TimeSlot, Booking
from .serializers import ServiceSerializer, TimeSlotSerializer, BookingSerializer


class ServiceListView(generics.ListAPIView):
    """GET /api/bookings/services/  — active services, e.g. for the booking-calendar service picker."""
    queryset = Service.objects.filter(active=True)
    serializer_class = ServiceSerializer
    permission_classes = [permissions.AllowAny]


class AvailableSlotsView(generics.ListAPIView):
    """
    GET /api/bookings/slots/?date=2026-09-23
    GET /api/bookings/slots/?from=2026-09-23&to=2026-09-30
    Returns open time slots for the calendar grid.
    """
    serializer_class = TimeSlotSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        qs = TimeSlot.objects.filter(is_available=True).order_by('date', 'start_time')

        single_date = self.request.query_params.get('date')
        date_from = self.request.query_params.get('from')
        date_to = self.request.query_params.get('to')

        if single_date:
            parsed = parse_date(single_date)
            if parsed:
                qs = qs.filter(date=parsed)
        elif date_from and date_to:
            start, end = parse_date(date_from), parse_date(date_to)
            if start and end:
                qs = qs.filter(date__range=[start, end])

        return qs


class BookingListCreateView(generics.ListCreateAPIView):
    """
    GET  /api/bookings/  — the logged-in user's bookings (for the dashboard "Upcoming bookings" panel)
    POST /api/bookings/  — create a booking, body: { service, slot, address, notes }
    """
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Booking.objects.filter(user=self.request.user).select_related(
            'service', 'slot'
        ).order_by('-slot__date', '-slot__start_time')

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        with transaction.atomic():
            # Lock the slot row to prevent a double-booking race condition
            slot = TimeSlot.objects.select_for_update().get(
                pk=request.data.get('slot')
            )
            if not slot.is_available:
                return Response(
                    {'slot': ['That time slot was just taken. Please pick another.']},
                    status=status.HTTP_409_CONFLICT,
                )
            booking = serializer.save()
        headers = self.get_success_headers(serializer.data)
        return Response(
            BookingSerializer(booking).data,
            status=status.HTTP_201_CREATED,
            headers=headers,
        )


class BookingDetailView(generics.RetrieveUpdateAPIView):
    """
    GET   /api/bookings/<id>/        — booking detail
    PATCH /api/bookings/<id>/        — e.g. { "status": "cancelled" }
    Only the owning user can view or update their booking.
    """
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Booking.objects.filter(user=self.request.user)

    def perform_update(self, serializer):
        booking = serializer.save()
        if booking.status == 'cancelled':
            booking.slot.is_available = True
            booking.slot.save(update_fields=['is_available'])
