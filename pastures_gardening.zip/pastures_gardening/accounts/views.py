import secrets
from django.contrib.auth import get_user_model
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from datetime import timedelta

from rest_framework import generics, permissions, status
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import UserProfile
from .serializers import (
    RegisterSerializer, LoginSerializer, UserSerializer,
    PasswordResetRequestSerializer, PasswordResetConfirmSerializer,
)

User = get_user_model()


class RegisterView(generics.CreateAPIView):
    """POST /api/accounts/register/  — { email, password, first_name, last_name, phone, address, postcode }"""
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        token, _ = Token.objects.get_or_create(user=user)
        return Response(
            {'token': token.key, 'user': UserSerializer(user).data},
            status=status.HTTP_201_CREATED,
        )


class LoginView(APIView):
    """POST /api/accounts/login/  — { email, password } -> { token, user }"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, _ = Token.objects.get_or_create(user=user)
        return Response({'token': token.key, 'user': UserSerializer(user).data})


class LogoutView(APIView):
    """POST /api/accounts/logout/ — deletes the current auth token."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        request.user.auth_token.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class ProfileView(generics.RetrieveUpdateAPIView):
    """GET/PATCH /api/accounts/profile/ — the logged-in user's own details."""
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user


class PasswordResetRequestView(APIView):
    """
    POST /api/accounts/password-reset/  — { email }
    Always returns 200 (doesn't reveal whether the email exists) and emails a reset link if it does.
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']

        try:
            user = User.objects.get(email__iexact=email)
            profile, _ = UserProfile.objects.get_or_create(user=user)
            profile.reset_token = secrets.token_urlsafe(32)
            profile.reset_expiry = timezone.now() + timedelta(hours=1)
            profile.save(update_fields=['reset_token', 'reset_expiry'])

            reset_link = f"{getattr(settings, 'FRONTEND_URL', '')}/reset-password?token={profile.reset_token}"
            send_mail(
                subject='Reset your PASTURES password',
                message=f'Use this link to set a new password (valid 1 hour): {reset_link}',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[email],
                fail_silently=True,
            )
        except User.DoesNotExist:
            pass

        return Response({'detail': 'If that email exists, a reset link has been sent.'})


class PasswordResetConfirmView(APIView):
    """POST /api/accounts/password-reset/confirm/ — { token, new_password }"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        token = serializer.validated_data['token']
        new_password = serializer.validated_data['new_password']

        try:
            profile = UserProfile.objects.get(reset_token=token)
        except UserProfile.DoesNotExist:
            return Response({'token': ['Invalid or expired reset link.']}, status=400)

        if not profile.reset_expiry or profile.reset_expiry < timezone.now():
            return Response({'token': ['This reset link has expired.']}, status=400)

        user = profile.user
        user.set_password(new_password)
        user.save(update_fields=['password'])
        profile.reset_token = None
        profile.reset_expiry = None
        profile.save(update_fields=['reset_token', 'reset_expiry'])

        return Response({'detail': 'Password updated. You can now sign in.'})
