from django.db import models
from django.contrib.auth.models import AbstractUser


class CustomUser(AbstractUser):
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)
    postcode = models.CharField(max_length=10, blank=True)
    SUBSCRIPTION_CHOICES = [('free', 'Free'), ('premium', 'Premium — AR & Maps')]
    subscription = models.CharField(max_length=20, choices=SUBSCRIPTION_CHOICES, default='free')
    subscribed_until = models.DateField(null=True, blank=True)


class UserProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='profile')
    email_verified = models.BooleanField(default=False)
    verification_token = models.CharField(max_length=64, blank=True, null=True)
    reset_token = models.CharField(max_length=64, blank=True, null=True)
    reset_expiry = models.DateTimeField(blank=True, null=True)
