import io
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfgen import canvas


def generate_invoice_pdf(invoice):
    """Returns a BytesIO buffer containing a simple, print-ready invoice PDF."""
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    c.setFillColor(colors.HexColor('#1E2B1C'))
    c.setFont('Helvetica-Bold', 20)
    c.drawString(20 * mm, height - 30 * mm, 'PASTURES')

    c.setFont('Helvetica', 10)
    c.setFillColor(colors.HexColor('#5B6650'))
    c.drawString(20 * mm, height - 37 * mm, 'Gardening & Maintenance')

    c.setFillColor(colors.black)
    c.setFont('Helvetica-Bold', 14)
    c.drawRightString(width - 20 * mm, height - 30 * mm, f'Invoice {invoice.invoice_ref}')
    c.setFont('Helvetica', 10)
    c.drawRightString(width - 20 * mm, height - 37 * mm, f'Issued {invoice.created_at.strftime("%d %b %Y")}')
    c.drawRightString(width - 20 * mm, height - 43 * mm, f'Due {invoice.due_date.strftime("%d %b %Y")}')

    y = height - 60 * mm
    c.setFont('Helvetica-Bold', 11)
    c.drawString(20 * mm, y, 'Billed to')
    c.setFont('Helvetica', 10)
    c.drawString(20 * mm, y - 6 * mm, invoice.user.get_full_name() or invoice.user.email)
    c.drawString(20 * mm, y - 12 * mm, invoice.user.address or '')

    y -= 30 * mm
    c.line(20 * mm, y, width - 20 * mm, y)
    y -= 8 * mm
    c.setFont('Helvetica-Bold', 10)
    c.drawString(20 * mm, y, 'Description')
    c.drawRightString(width - 20 * mm, y, 'Amount')
    y -= 4 * mm
    c.line(20 * mm, y, width - 20 * mm, y)

    y -= 10 * mm
    c.setFont('Helvetica', 10)
    description = invoice.quote.quote_ref if invoice.quote else 'Gardening services'
    amount = invoice.quote.ai_estimate if invoice.quote else 0
    c.drawString(20 * mm, y, description)
    c.drawRightString(width - 20 * mm, y, f'£{amount:.2f}')

    y -= 14 * mm
    c.line(20 * mm, y, width - 20 * mm, y)
    y -= 8 * mm
    c.setFont('Helvetica-Bold', 12)
    c.drawString(20 * mm, y, 'Total due')
    c.drawRightString(width - 20 * mm, y, f'£{amount:.2f}')

    c.setFont('Helvetica', 8)
    c.setFillColor(colors.HexColor('#8A9179'))
    c.drawString(20 * mm, 15 * mm, 'PASTURES Gardening & Maintenance · hello@pastures-gardening.co.uk')

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer
