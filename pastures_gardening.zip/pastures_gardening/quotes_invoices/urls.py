from django.urls import path
from . import views

app_name = 'quotes_invoices'

urlpatterns = [
    path('quotes/', views.QuoteListView.as_view(), name='quote-list'),
    path('quotes/from-photo/', views.QuoteFromPhotoView.as_view(), name='quote-from-photo'),
    path('quotes/<int:pk>/accept/', views.QuoteAcceptView.as_view(), name='quote-accept'),
    path('invoices/', views.InvoiceListView.as_view(), name='invoice-list'),
    path('invoices/<int:pk>/', views.InvoiceDetailView.as_view(), name='invoice-detail'),
    path('invoices/<int:pk>/pdf/', views.InvoicePDFView.as_view(), name='invoice-pdf'),
]
