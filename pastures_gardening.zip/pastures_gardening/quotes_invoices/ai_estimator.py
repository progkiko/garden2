from decimal import Decimal
from PIL import Image

SERVICE_PRICES = {
    'hedge_trimming': 95.00, 'lawn_mowing': 35.00,
    'garden_tidying': 65.00, 'full_maintenance': 180.00,
}


def estimate_price(services, size='medium', condition='standard'):
    base = sum(SERVICE_PRICES.get(s, 50.00) for s in services)
    factor = {'small': 0.8, 'medium': 1.0, 'large': 1.4, 'overgrown': 1.8}.get(size, 1.0)
    if condition == 'overgrown':
        factor *= 1.3
    return Decimal(round(base * factor, 2))


def analyze_photo(image_path):
    try:
        img = Image.open(image_path).convert('L')
        avg_brightness = sum(list(img.getdata())) / len(list(img.getdata()))
        if avg_brightness < 90:
            return {'detected_services': ['hedge_trimming', 'garden_tidying'], 'size': 'medium', 'condition': 'overgrown', 'confidence': 0.85}
        return {'detected_services': ['lawn_mowing'], 'size': 'medium', 'condition': 'standard', 'confidence': 0.85}
    except Exception:
        return {'detected_services': ['hedge_trimming', 'garden_tidying'], 'size': 'medium', 'condition': 'standard', 'confidence': 0.70}
