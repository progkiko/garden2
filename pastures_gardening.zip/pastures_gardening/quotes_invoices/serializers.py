from rest_framework import serializers
from .models import Quote, Invoice


class QuoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Quote
        fields = [
            'id', 'quote_ref', 'address', 'photo_upload',
            'ai_estimate', 'status', 'valid_until', 'created_at',
        ]
        read_only_fields = ['quote_ref', 'ai_estimate', 'status', 'valid_until', 'created_at']


class QuoteRequestSerializer(serializers.Serializer):
    """Input for creating a quote from an uploaded photo."""
    address = serializers.CharField()
    photo = serializers.ImageField()


class InvoiceSerializer(serializers.ModelSerializer):
    quote_ref = serializers.CharField(source='quote.quote_ref', read_only=True)
    amount = serializers.DecimalField(source='quote.ai_estimate', max_digits=10, decimal_places=2, read_only=True)

    class Meta:
        model = Invoice
        fields = ['id', 'invoice_ref', 'quote', 'quote_ref', 'amount', 'paid', 'due_date', 'created_at']
        read_only_fields = ['invoice_ref', 'paid', 'created_at']
