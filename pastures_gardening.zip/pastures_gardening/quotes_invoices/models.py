from django.db import models
from django.conf import settings


class Quote(models.Model):
    STATUS_CHOICES = [('draft', 'Draft'), ('sent', 'Sent'), ('accepted', 'Accepted'), ('converted', 'Converted')]
    quote_ref = models.CharField(max_length=20, unique=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    address = models.TextField()
    photo_upload = models.ImageField(upload_to='quote_photos/', blank=True)
    ai_estimate = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    valid_until = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)


class Invoice(models.Model):
    invoice_ref = models.CharField(max_length=20, unique=True)
    quote = models.OneToOneField(Quote, null=True, on_delete=models.SET_NULL)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    paid = models.BooleanField(default=False)
    due_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
