import random
import string
from datetime import timedelta

from django.http import FileResponse
from django.utils import timezone
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Quote, Invoice
from .serializers import QuoteSerializer, QuoteRequestSerializer, InvoiceSerializer
from .ai_estimator import analyze_photo, estimate_price
from .pdf_gen import generate_invoice_pdf


def _make_ref(prefix):
    suffix = ''.join(random.choices(string.digits, k=4))
    return f'{prefix}-{timezone.now().year}-{suffix}'


class QuoteListView(generics.ListAPIView):
    """GET /api/quotes/ — the logged-in user's quotes."""
    serializer_class = QuoteSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Quote.objects.filter(user=self.request.user).order_by('-created_at')


class QuoteFromPhotoView(APIView):
    """
    POST /api/quotes/from-photo/  (multipart/form-data: address, photo)
    Runs the AI estimator on the uploaded photo and returns a priced, savable quote.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = QuoteRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        photo = serializer.validated_data['photo']
        address = serializer.validated_data['address']

        quote = Quote.objects.create(
            quote_ref=_make_ref('Q'),
            user=request.user,
            address=address,
            photo_upload=photo,
            valid_until=timezone.now().date() + timedelta(days=14),
            status='draft',
        )

        analysis = analyze_photo(quote.photo_upload.path)
        price = estimate_price(
            services=analysis['detected_services'],
            size=analysis['size'],
            condition=analysis['condition'],
        )
        quote.ai_estimate = price
        quote.status = 'sent'
        quote.save(update_fields=['ai_estimate', 'status'])

        return Response(
            {
                'quote': QuoteSerializer(quote).data,
                'analysis': analysis,
            },
            status=status.HTTP_201_CREATED,
        )


class QuoteAcceptView(APIView):
    """POST /api/quotes/<id>/accept/ — converts an accepted quote into an unpaid invoice."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            quote = Quote.objects.get(pk=pk, user=request.user)
        except Quote.DoesNotExist:
            return Response({'detail': 'Quote not found.'}, status=404)

        if quote.status == 'converted':
            return Response({'detail': 'This quote has already been converted.'}, status=400)

        quote.status = 'converted'
        quote.save(update_fields=['status'])

        invoice = Invoice.objects.create(
            invoice_ref=_make_ref('INV'),
            quote=quote,
            user=request.user,
            due_date=timezone.now().date() + timedelta(days=7),
        )
        return Response(InvoiceSerializer(invoice).data, status=status.HTTP_201_CREATED)


class InvoiceListView(generics.ListAPIView):
    """GET /api/invoices/ — the logged-in user's invoices."""
    serializer_class = InvoiceSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Invoice.objects.filter(user=self.request.user).select_related('quote').order_by('-created_at')


class InvoiceDetailView(generics.RetrieveAPIView):
    """GET /api/invoices/<id>/ — single invoice, e.g. for the quote-invoice screen."""
    serializer_class = InvoiceSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Invoice.objects.filter(user=self.request.user)


class InvoicePDFView(APIView):
    """GET /api/invoices/<id>/pdf/ — streams a downloadable PDF, used by the 'Download PDF' button."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk):
        try:
            invoice = Invoice.objects.select_related('quote', 'user').get(pk=pk, user=request.user)
        except Invoice.DoesNotExist:
            return Response({'detail': 'Invoice not found.'}, status=404)

        buffer = generate_invoice_pdf(invoice)
        return FileResponse(buffer, as_attachment=True, filename=f'{invoice.invoice_ref}.pdf')
